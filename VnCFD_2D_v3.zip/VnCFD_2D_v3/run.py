# coding: utf-8
# Copyright (C) 2019  Nguyen Ngoc Sang, <https://github.com/SangVn>

from lib.data import Blocks
# from setting import P_left, P_right # test1D
from setting import P_t0

def run():
    blocks = Blocks(btype='ns')
    # blocks.init_field_test1D(P_left, P_right) # test1D
    blocks.init_field() # default: P_t0 = P_freestream
    # blocks.init_field(P_t0=P_t0)
    blocks.run()
    blocks.export_block_data('field_bd.dat')
    # blocks.plot_field(field='p', pfunc='pcolor')

if __name__ == '__main__':
    run()
