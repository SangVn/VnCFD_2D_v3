# coding: utf-8
# Copyright (C) 2019  Nguyen Ngoc Sang, <https://github.com/SangVn>

from numpy import array, zeros, loadtxt, sin, cos, deg2rad
from re import findall
from constants import *

# inner cell bên cạnh mặt trên biên (i= 0, 1, 2, 3) -> (ic= 1, 0, 1, 0)
def bound_inner_cell(i):
    return (i+1)%2

#  (i= 0, 1, 2, 3) -> (si= 0, 0, 1, 1)
def bound_side_id(i):
    if (i==0) or (i==1): return 0
    else: return 1

# Hàm sign_ic: xác định `thêm hay bớt` dòng ở ô lưới kề bên side
def sign_ic(ic): #ic ~ index_cell; left_cell: ic = 0; right_cell: ic = 1
    if ic == 0: return -1.0 # res -= flux
    else: return 1.0        # res += flux

# Lấy index cell nằm ở phía bên kia của side
def opposite_ic(ic):
    if ic==0: return 1
    else: return 0

# hàm xác định khối lượng riêng phụ thuộc nhiệt độ và áp suất
# theo phương trình trạng thái
def rho(T, p):
    return p/(R_gas*T)

def Temperature(P):
    return P[3]/(R_gas*P[0])

# vận tốc âm thanh
def VSound(P):
    return (gamma * P[3] / P[0]) ** 0.5

# hàm tính số mach
def Mach(P):
    a = (gamma * P[3] / P[0]) ** 0.5
    u = (P[1] * P[1] + P[2] * P[2]) ** 0.5
    M = u / a
    return M

def Psym(P, N):
    Ps = P.copy()
    Vn2 = 2*(P[1]*N[0] + P[2]*N[1])
    Ps[1] -= Vn2*N[0]
    Ps[2] -= Vn2*N[1]
    return Ps

# t - total
def Pt2P(M=0.0, Tt=293.15, pt=101.325, alf=0.0):
    m = 1.0/(1.0+M*M*gamma_m1/2.0)
    T = Tt*m
    p = pt*(m**(gamma/gamma_m1))
    r = rho(T, p)
    a = (gamma*p/r)**0.5
    V = M*a
    alf = deg2rad(alf)
    return array([r, V*cos(alf), V*sin(alf), p])

def P2Pt(P):
    r, u, v, p = P[0], P[1], P[2], P[3]
    M = Mach(P)
    m = (1.0+M*M*gamma_m1/2.0)
    T = Temperature(P)
    Tt = T*m
    pt = p*(m**(gamma/gamma_m1))
    rt = r*(m**(1.0/gamma_m1))
    return rt, pt, Tt

def Pm2P(M=0.0, T=293.15, p=101.325, alf=0.0):
    r = rho(T, p)
    a = (gamma*p/r)**0.5
    V = M*a
    alf = deg2rad(alf)
    return array([r, V*cos(alf), V*sin(alf), p])

def muT(T):
    return c_mu * T ** 1.5 / (T + 122.)

def muP(P):
    T = Temperature(P)
    return c_mu * T ** 1.5 / (T + 122.)

def reynolds_number(P, L):
    r = P[0]
    T = Temperature(P)
    mu = muT(T)
    V = (P[1]*P[1]+P[2]*P[2])**0.5
    Re_L = r*V*L/mu
    return Re_L

def root_T_bisect(mu):
    dmu_func = lambda T: c_mu * T ** 1.5 / (T + 122.0) - mu
    T_left = 0.0
    T_right = 1000.0
    while True:
        T_mean = 0.5 * (T_left + T_right)
        dmu_mean = dmu_func(T_mean)
        if abs(dmu_mean) < 1e-8: return T_mean

        dmu_left = dmu_func(T_left)
        if (dmu_left * dmu_mean > 0): T_left = T_mean
        else: T_right = T_mean

def Pmu2P(U, rho, mu):
    T = root_T_bisect(mu)
    p = rho*R_gas*T
    return array([rho, U[0], U[1], p])

def P2U(P):
    U = zeros(4)
    U[0] = P[0]
    U[1] = P[0] * P[1]
    U[2] = P[0] * P[2]
    U[3] = P[3] / gamma_m1 + 0.5 * P[0] * (P[1] ** 2 + P[2] ** 2)
    return U

# Hàm P2F: tính dòng qua mặt (công thức ở bài 18)
def P2F(P, side):
    n = side.normal    #vector pháp tuyến đơn vị của mặt
    vn = n.dot(P[1:3]) #vận tốc vuông góc bề mặt V.n
    F = zeros(4)
    F[0] = P[0] * vn
    F[1] = F[0] * P[1] + P[3] * n[0]
    F[2] = F[0] * P[2] + P[3] * n[1]
    F[3] = F[0] * (P[3] / P[0] * gamma / gamma_m1 + 0.5 * (P[1] ** 2 + P[2] ** 2))
    return F * side.area

# Hàm U2P: xác định biến biên thủy P từ biến bảo toàn U
def U2P(U, P):
    P[0] = U[0]
    P[1] = U[1] / U[0]
    P[2] = U[2] / U[0]
    P[3] = (U[3] - 0.5 * P[0] * (P[1] ** 2 + P[2] ** 2)) * gamma_m1

'''
*********************************
    Primitive variables Gradient:
    G[0] = [r'_x u'_x v'_x p'_x]
    G[1] = [r'_y u'_y v'_y p'_y]
    
    Viscous stress Tensor:
    Tau[0] = [tau_xx tau_xy]
    Tau[1] = [tau_yx tay_yy]
*********************************
'''
# hàm chuyển P từ hệ tọa độ (x,y) sang (xi, eta)
def P_transform(P, J):
    V_tran = J.dot([P[1], P[2]]) # J*(u,v)
    return array([P[0], V_tran[0], V_tran[1], P[3]])

# diffusion coefficient in N-S equations
# D = 1/rho max(4/3 mu, mu/Pr)
def diff_ns(P):
    mu = muP(P)
    rho = P[0]
    D = mu/(Pr*rho)
    return D

# hàm xác định tensor lực nhớt
def viscous_stress_tensor(G, mu):
    mu_m2 = -mu * 2.0
    divV_d3 = (G[0, 1] + G[1, 2])/3.0
    Tau = zeros((2,2))
    Tau[0, 1] = Tau[1, 0] = -mu * (G[0, 2] + G[1, 1])
    Tau[0, 0] = mu_m2 * (G[0, 1] - divV_d3)
    Tau[1, 1] = mu_m2 * (G[1, 2] - divV_d3)
    return Tau

# hàm xác định gradient nhiệt độ gT
# T = p/(R*r), T' = p'/(R*r) - p*r'/(R*r^2)
# gT = [T'_x, T'_y]
def grad_T(P, G):
    Rr_inverse = 1.0/(R_gas*P[0])
    gTx = (G[0, 3] - G[0, 0] * P[3] / P[0]) * Rr_inverse
    gTy = (G[1, 3] - G[1, 0] * P[3] / P[0]) * Rr_inverse
    return array([gTx, gTy])

def P2F_diff(P, G, side):
    n = side.normal
    m = muP(P)
    Tau = viscous_stress_tensor(G, m)
    q = cp_dPr*m*grad_T(P, G)
    heat_flux = n.dot(q)

    F = zeros(4)
    F[0] = 0.0
    F[1] = n.dot(Tau[0])
    F[2] = n.dot(Tau[1])
    F[3] = F[1]*P[1] + F[2]*P[2] - heat_flux

    return F*side.area


# Hàm đọc lưới gồm nhiều block
def import_mesh(file_name):
    print('\nImport mesh from: %s\n' % file_name)
    zone_n = 0
    zone_names = []
    zone_id = []
    with open(file_name, 'r') as f:
        for line in f:
            if line[:4] == 'ZONE': # ví dụ: ZONE T="1", I=60, J=40
                zone_n += 1
                # lấy giá trị số thứ tự Block T, số điểm lưới IxJ (NixNj)
                ints = list(map(int, findall(r'\d+', line)))
                zone_names.append(str(ints[0]))
                zone_id.append([ints[1], ints[2]])

    # đọc tọa độ các điểm lưới bằng hàm loadtxt, bỏ 3 hàng đầu
    # dùng reshape để chuyển mảng về 3 chiều
    try: nodes = loadtxt(file_name, usecols=(0, 1), delimiter=' ', skiprows=3, comments=['Z'])
    except: nodes = loadtxt(file_name, usecols=(0, 1), delimiter=',', skiprows=3, comments=['Z'])

    zone_nodes = []
    node_start = 0
    for i in range(zone_n):
        Ni, Nj = zone_id[i][0], zone_id[i][1]
        node_end = node_start + Ni*Nj
        nodes_in = nodes[node_start: node_end].reshape((Nj, Ni, 2))
        node_start = node_end
        zone_nodes.append(nodes_in)

    return zone_n, zone_names, zone_nodes