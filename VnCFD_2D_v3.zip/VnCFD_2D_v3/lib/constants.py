# coding: utf-8
# Copyright (C) 2019  Nguyen Ngoc Sang, <https://github.com/SangVn>

gamma = 1.4 # số mũ đoạn nhiệt
gamma_m1 = 0.4 # gamma - 1
R_gas = 287.052873836 # hằng số chất khí
cp = gamma*R_gas/gamma_m1
Pr = 0.72   # số Prandtl
Pr_inverse = 1.0/0.72
cp_dPr = cp*Pr_inverse
c_mu = 1.72e-5*(273+122.)/273.**1.5 # hằng số để tính đột nhớt
