# coding: utf-8
# Copyright (C) 2019  Nguyen Ngoc Sang, <https://github.com/SangVn>

from time import time as timer
from numpy import cross, zeros, array, fromfile
import matplotlib.pyplot as plt
from functions import P2U, U2P, Mach, Temperature, import_mesh, P2F_diff
from functions import bound_inner_cell, bound_side_id, sign_ic, P_transform, diff_ns, Psym
from solver import eu_solver
from setting import P_freestream, mesh_file, joint_list, boco_list, path_dir
from setting import no_slip, moving_wall, symmetry

'''
    ------------------------------------
    Phần I: Lớp dữ liệu "Cells"
    ------------------------------------
'''
def mod(vec):
    '''Tính độ dài vector: vec = (point2 - point1)'''
    return (vec[0]*vec[0] + vec[1]*vec[1])**0.5

def unit(vec):
    '''Tìm vector đơn vị'''
    return vec/mod(vec)

def t2n(vec):
    '''Tìm vector vuông góc'''
    return array([vec[1], -vec[0]])

def n2t(vec):
    return array([-vec[1], vec[0]])

def center(vertices):
    '''
    :param vertices: vertices: array tọa độ bốn đỉnh ô lưới theo thứ tự ngược chiều KĐH
    3 ____ 2
    0|____|1
    :return: center - tọa độ tâm ô lưới bằng trung bình cộng tọa độ bốn đỉnh lưới
    '''
    return sum(vertices) / 4.

def volume(vertices):
    '''
    :param vertices: array tọa độ bốn đỉnh ô lưới theo thứ tự ngược chiều KĐH
    :return: volume - thể tích ô lưới, trong trường hợp 2 chiều - diện tích ô lưới:
                      bằng một nửa độ lớn tích có hướng hai vector đường chéo
    '''
    return abs(cross(vertices[0] - vertices[2], vertices[1] - vertices[3]) / 2.)

def interpolation(fL, dL, fR, dR):
    return (dR*fL + dL*fR)/(dL+dR)

def extrapolation(f1, d1, f2, d2):
    return f1 + (f1-f2)*d1/d2

'''
    Jacobi 2x2:
    V(x,y) = J*V(i,j)
    V(i,j) = J_inv*V(x,y)
'''
def Jacobi_inverse(J):
    det = J[0, 0] * J[1, 1] - J[0, 1] * J[1, 0]
    return array([[J[1, 1], -J[0, 1]], [-J[1, 0], J[0, 0]]]) / det

def cell_size(vertices):
    '''
    :param vertices: array tọa độ bốn đỉnh ô lưới theo thứ tự ngược chiều KĐH
    :return: size  - kích thước ô lưới [dx, dy]
    '''
    di_vec = (vertices[1] - vertices[0] + vertices[2] - vertices[3])/2.
    dj_vec = (vertices[3] - vertices[0] + vertices[2] - vertices[1])/2.

    J_inv = array([unit(di_vec), unit(dj_vec)]).T
    J = Jacobi_inverse(J_inv)

    di = mod(di_vec)
    dj = mod(dj_vec)
    return array([di, dj]), J, J_inv

class Cell:
    '''
    Lớp dữ liệu Cell chứa  các thông số cơ bản của một ô lưới.

                    nodes[3]        cells[3], sides[3]      nodes[2]
                        -----------------------------------------
                        |                                       |
    cells[0], sides[0]  |                    *                  | cells[1], sides[1]
                        |                                       |
                        -----------------------------------------
                    nodes[0]        cells[2], sides[2]      nodes[1]
    Parameters
    ----------
    vertices : 4 đỉnh lưới theo thứ tự ngược chiều KĐH dùng để xác định center, volume, size

    Attributes
    ----------
    center: tạo độ tâm
    volume: thể tích
    size:   kích thước
    P:   biến nguyên thủy (rho, u, v, p)
    U:   biến bảo toàn (rho, rho*u, rho*v, e), e = p/(gamma-1) + rho*(u^2 + v^2)/2
    res: biến tổng dòng qua các bề mặt sum(F*S)
    dt:  bước thời gian trong ô lưới.

    Notes
    -----
    Tại thời điểm khởi tạo P, U, res, dt bằng 0
    '''
    def __init__(self, vertices):
        'Khởi tạo Cell từ 4 đỉnh vertices.'
        self.center   = center(vertices)
        self.volume   = volume(vertices)
        self.size, self.J, self.J_inv = cell_size(vertices)
        self.P = zeros(4)
        self.U = zeros(4)
        self.G = zeros((2, 4)) # Gradient for N-S
        self.res = zeros(4)
        self.dt  = 0.0
        self.sides = [None, None, None, None] # list 4 sides xung quanh [s0, s1, s2, s3]
        self.cells = [None, None, None, None] # list 4 cells hàng xóm [c0, c1, c2, c3]

# Class Ghost Cell
class GhostCell():
    def __init__(self, size):
        self.P = zeros(4)
        self.size = [0.0, 0.0] # n=size


class euCells():
    '''
    Lớp dữ liệu các ô lưới trong một block (zone).

    Parameters
    ----------
    nodes : mảng 2D các tọa độ các điểm lưới có kích thước (Nj+1)*(Ni+1)

    Attributes
    ----------
    size:  kích thước lưới 2D ([Nj, Ni])
    len:   tổng số ô lưới (Nj*Ni)
    cells: dãy các ô lưới "class Cell".

    Notes
    -----
    Ô lưới thứ (j,i) (hay thứ j*i) gồm 4 đỉnh [(j,i), (j,i+1), (j+1,i+1), (j+1,i)]
    '''
    def __init__(self, nodes):
        '''Khởi tạo Cells từ mảng nodes.'''
        Nj, Ni = nodes.shape[0]-1, nodes.shape[1]-1
        self.size  = [Nj, Ni]
        self.len   = Nj*Ni
        self.cells = []
        for j in range(Nj):
            for i in range(Ni):
                vers = (nodes[j, i], nodes[j, i + 1], nodes[j + 1, i + 1], nodes[j + 1, i])
                self.cells.append(Cell(vers))

    def __getitem__(self, item):
        '''
        Các phương thức cơ bản để lấy các phần tử của dãy các ô lưới "cells":
        :param item: có thể là kiểu tuple (j, i), int j*i hay để getslice [start:stop]
        :return: một hoặc một đoạn các ô lưới
        '''
        if isinstance(item, tuple): # Lấy ô lưới thứ (j,i): cells[j,i]
            j, i = item
            if (j < 0): j += self.size[0]
            if (i < 0): i += self.size[1]
            return self.cells[j * self.size[1] + i]
        else: # Lấy một đoạn các ô lưới: cells[start:stop] (getslice). Lấy ô lưới thứ j*i: cells[j*i]
            return self.cells[item]

    def eu_time_step_cell(self):
        '''Tính bước thời gian cục bộ trong từng ô lưới.'''
        for cell in self.cells:
            a = (1.4 * cell.P[3] / cell.P[0]) ** 0.5      # vận tốc âm thanh
            v = (cell.P[1] ** 2 + cell.P[2] ** 2) ** 0.5  # vận tốc dòng chảy
            cell.dt = min(cell.size)/(v + a)

    def time_step_global(self, CFL):
        '''
        Xác định bước thời gian cho toàn vùng tính toán block (zone).
        :param CFL: số CFL, phụ thuộc sơ đồ tính toán.
        :return: dt - bước thời gian cho mỗi iteration
        '''
        self.eu_time_step_cell() # trước hết cần xác định bước thời gian trong từng ô lưới
        dt = 1e6
        for cell in self.cells: # sau đó tìm bước thời gian nhỏ nhất trong toàn block
            dt = min(dt, cell.dt)          
        return CFL*dt

    def new_U(self, dt):
        '''Thực hiện bước lặp: xác định U ở bước thời gian tiếp theo.'''
        for cell in self.cells:
            cell.U += dt/cell.volume*cell.res # công thức: U^{n+1} = U^{n}  + dt/dx*RES
            cell.res[:] = 0.0                 # sau khi xác định U, đưa giá trị res về 0.0

    def new_P(self):
        '''Thực hiện bước lặp: xác định P ở bước thời gian tiếp theo, sử dụng hàm U2P.'''
        for cell in self.cells:
            U2P(cell.U, cell.P)

'''
    ------------------------------------
    Phần II: Lớp dữ liệu "Sides"
    ------------------------------------
'''

#định nghĩa lớp bề mặt
class Side:
    '''
    Lớp Side chứa các thông số cơ bản của một bề mặt của ô lưới.

    Parameters
    ----------
    side_vec : vector side = (point2 - point1)

    Attributes
    ----------
    area:   diện tích bề mặt, 2D - chiều dài cạnh
    normal: vector pháp tuyến đơn vị
    cells:  hai ô lưới hai bên trái phải.
            Quy ước: self.cells[0] - ô bên trái, self.cells[1] - ô bên phải
    '''
    def __init__(self, vertices, id):
        '''Khởi tạo Side từ vector side_vec (node_2 - node_1).'''
        self.center = 0.5*(vertices[0]+vertices[1])
        side_vec = vertices[1] - vertices[0]
        self.area   = mod(side_vec) # 2D - độ dài cạnh đóng vai trò là diện tích bề mặt
        self.normal = unit(t2n(side_vec)) # lấy vector vuông góc
        self.id = id # 0 - dọc theo phương j, 1 - dọc theo phương i
        self.P = zeros(4)
        self.J = None
        self.G = zeros((2, 4))
        self.cells = None
        self.joint = False

class euSides:
    '''
    Lớp dữ liệu các bề mặt trong một vùng tính toán block (zone).
    Sides gồm hai loại:
        + Side bên trong vùng tính toán
        + Side trên biên
        __________
        |__|__|__|
        |__|__|__|
        |__|__|__|
    Quy ước:
        Mỗi vùng tính toán block có 4 biên:
                        bound_3
                       <--------
                   ^               ^
            bound_0|  inner_sides  |bound_1

                       <--------
                        bound_2
    Parameters
    ----------
    nodes : mảng chứa tọa độ các điểm lưới
    cells : dãy các ô lưới

    Attributes
    ----------
    bounds : list
            [bound_0, bound_1, bound_2, bound_3]
    inner_sides : list
            tất cả các sides bên trong
    boco_list : list
            các điều kiện biên trên 4 biên [boco_bound_0, boco_bound_1, boco_bound_2, boco_bound_3],
            mỗi boco_bound_i là một list các điều kiện biên trên biên i.
    '''

    def __init__(self, nodes, cells):
        '''Khởi tạo Sides từ nodes và cells.'''
        #xác định các vector bề mặt từ các điểm lưới
        nodes_size = nodes.shape

        # Biên_0 gồm các mặt ở cột đầu sides_j
        # Ô lưới bên trái không xác định, bên phải là các ô ở cột đầu tiên
        bound_0 = []
        for j in range(nodes_size[0]-1):
            side = Side((nodes[j,0], nodes[j+1,0]), 0)
            side.cells = [GhostCell(cells[j, 0].size), cells[j, 0]]
            bound_0.append(side)

        # Biên_1 gồm các mặt ở cột cuối sides_j
        # Ô lưới bên phải không xác định, bên trái là các ô ở cột cuối
        bound_1 = []
        for j in range(nodes_size[0]-1):
            side = Side((nodes[j, -1], nodes[j+1, -1]), 0)
            side.cells = [cells[j, -1], GhostCell(cells[j, -1].size)]
            bound_1.append(side)

        # Biên_2 gồm các mặt ở hàng đầu sides_i
        # Ô lưới bên phải không xác định, bên trái là các ô ở hàng đầu
        bound_2 = []
        for i in range(nodes_size[1]-1):
            side = Side((nodes[0, i+1], nodes[0, i]), 1)
            side.cells = [GhostCell(cells[0, i].size), cells[0, i]]
            bound_2.append(side)

        # Biên_3 gồm các mặt ở hàng cuối sides_i
        # Ô lưới bên trái không xác định, bên phải là các ô ở hàng cuối
        bound_3 = []
        for i in range(nodes_size[1]-1):
            side = Side((nodes[-1, i+1], nodes[-1, i]), 1)
            side.cells = [cells[-1, i], GhostCell(cells[-1, i].size)]
            bound_3.append(side)

        self.bounds = [bound_0, bound_1, bound_2, bound_3]

        # Những hàng còn lại bên trong sides_i
        self.inner_sides = []
        for j in range(1, nodes_size[0]-1):
            for i in range(nodes_size[1]-1):
                side = Side((nodes[j, i+1], nodes[j, i]), 1)
                side.cells = [cells[j - 1, i], cells[j, i]]
                self.inner_sides.append(side)

        # Những cột còn lại bên trong sides_j
        for i in range(1, nodes_size[1]-1):
            for j in range(nodes_size[0]-1):
                side = Side((nodes[j, i], nodes[j+1, i]), 0)
                side.cells = [cells[j, i - 1], cells[j, i]]
                self.inner_sides.append(side)

        # xác định các ô lưới và các mặt "hàng xóm" của mỗi ô lưới
        # mỗi ô lưới được bao quanh bởi 4 ô lưới và 4 mặt, id (0, 1, 2, 3), vị trí giống như của 4 biên
        for side in self.bounds[0]:
            side.cells[1].cells[0] = side.cells[0]
            side.cells[1].sides[0] = side
        for side in self.bounds[1]:
            side.cells[0].cells[1] = side.cells[1]
            side.cells[0].sides[1] = side
        for side in self.bounds[2]:
            side.cells[1].cells[2] = side.cells[0]
            side.cells[1].sides[2] = side
        for side in self.bounds[3]:
            side.cells[0].cells[3] = side.cells[1]
            side.cells[0].sides[3] = side
        for side in self.inner_sides:
            id = side.id*2
            side.cells[0].cells[id+1] = side.cells[1]
            side.cells[0].sides[id+1] = side
            side.cells[1].cells[id] = side.cells[0]
            side.cells[1].sides[id] = side

    def set_boco_list(self, boco_list):
        '''Thiết lập giá trị thuộc tính boco_list.'''
        self.boco_list = boco_list

    def set_joint(self, boundary_0, boundary_1, ib0=0, ib1=1): #ib - index boundary
        '''Kết nối các mặt với điều kiện biên joint.'''
        if len(boundary_0) != len(boundary_1):
            print('ValueError in set_joint: bound_0 and bound_1 have different lengths (%d, %d).' % (len(boundary_0), len(boundary_1)))
            exit(0)

        oc0 = ib0%2 #boundary_0.outer_cell
        ic0 = (ib0+1)%2 #boundary_0.inner_cell
        # xác định lại 'cell hàng xóm' của side và cell trên biên joint
        for side_0, side_1 in zip(boundary_0, boundary_1):
            side_0.cells[oc0] = side_1.cells[oc0]
            side_1.cells[ic0] = side_0.cells[ic0]
            side_0.cells[ic0].cells[ib0] = side_1.cells[oc0]
            side_1.cells[oc0].cells[ib1] = side_0.cells[ic0]

            self.inner_sides.append(side_0)
            side_0.joint = True
            side_1.joint = True

    def flux_bound_sides(self, flux_func):
        '''
        Tính dòng qua các sides trên biên.
        :param flux_func: hàm tính dòng qua side
        '''
        for i, bound in enumerate(self.bounds):
            for boco in self.boco_list[i]: boco[0](bound[boco[1]:boco[2]], (i+1)%2, flux_func)

    def flux_inner_sides(self, flux_func):
        '''
        Tính dòng qua các sides bên trong vùng tính.
        :param flux_func: hàm tính dòng qua side
        '''
        for side in self.inner_sides:
            F = flux_func(side, side.cells[0].P, side.cells[1].P)
            side.cells[0].res -= F # ô bên trái -
            side.cells[1].res += F # ô bên phải +


'''
    -------------------------------
        Navier-Stokes data
    -------------------------------    
'''
class nsCells(euCells):
    def gradient_central_diff(self):
        '''Tính gradient tại tâm ô lưới'''
        for cell in self.cells:
            d_xi_L = 0.5 * (cell.size[0] + cell.cells[0].size[0])
            d_xi_R = 0.5 * (cell.size[0] + cell.cells[1].size[0])
            dP_xi_L = cell.P - cell.cells[0].P
            dP_xi_R = cell.cells[1].P - cell.P
            dP_xi_L = P_transform(dP_xi_L, cell.J)
            dP_xi_R = P_transform(dP_xi_R, cell.J)
            P_xi = interpolation(dP_xi_L/d_xi_L, d_xi_L, dP_xi_R/d_xi_R, d_xi_R)
            P_xi = P_transform(P_xi, cell.J_inv)

            d_eta_L = 0.5 * (cell.size[1] + cell.cells[2].size[1])
            d_eta_R = 0.5 * (cell.size[1] + cell.cells[3].size[1])
            dP_eta_L = cell.P - cell.cells[2].P
            dP_eta_R = cell.cells[3].P - cell.P
            dP_eta_L = P_transform(dP_eta_L, cell.J)
            dP_eta_R = P_transform(dP_eta_R, cell.J)
            P_eta = interpolation(dP_eta_L/d_eta_L, d_eta_L, dP_eta_R/d_eta_R, d_eta_R)
            P_eta = P_transform(P_eta, cell.J_inv)

            cell.G = array([P_xi, P_eta])
        return


    def ns_time_step_cell(self):
        '''Tính bước thời gian cục bộ trong từng ô lưới'''
        for cell in self.cells:
            a = (1.4 * cell.P[3] / cell.P[0]) ** 0.5  # vận tốc âm thanh
            V = (cell.P[1] ** 2 + cell.P[2] ** 2) ** 0.5  # vận tốc dòng chảy
            tau_conv = cell.size/(a+V)
            D = diff_ns(cell.P)
            tau_diff = cell.size**2/D
            tau_inv = (1.0 + (1.0+tau_diff/tau_conv)**0.5)**2/tau_diff
            cell.dt = 1.0/sum(tau_inv)

    def time_step_global(self, CFL):
        '''Xác định bước thời gian cho toàn vùng tính toán (block)'''
        self.ns_time_step_cell()  # trước hết cần xác định bước thời gian trong từng ô lưới
        dt = 1e6
        for cell in self.cells:  # sau đó tìm bước thời gian nhỏ nhất trong toàn block
            dt = min(dt, cell.dt)
        return CFL * dt

class nsSides(euSides):
    def __init__(self, nodes, cells):
        super().__init__(nodes, cells)
        # Xác định ma trận Jacobi cho các mặt bên trong
        #   |
        #   |---> n0   ^ n1
        #   |__________|_________
        # tan - tangent, nor - normal
        for side in self.inner_sides:
            xy_tan = n2t(side.normal)
            xy_nor_L = unit(side.center - side.cells[0].center)
            xy_nor_R = unit(side.cells[1].center - side.center)
            d_nor_L = side.cells[0].size[side.id]
            d_nor_R = side.cells[1].size[side.id]
            xy_nor = interpolation(xy_nor_L, d_nor_L, xy_nor_R, d_nor_R)
            if side.id == 0: J = array([xy_nor, xy_tan]).T
            else: J = array([-xy_tan, xy_nor]).T #!!!!
            side.J = Jacobi_inverse(J)

        # Xác định ma trận Jacobi cho các mặt trên biên
        for i, bound in enumerate(self.bounds):
            ic = (i + 1) % 2  # index inner cell
            for side in bound:
                if side.joint == False:
                    xy_tan = n2t(side.normal)
                    if ic == 0: xy_nor = unit(side.center-side.cells[0].center)
                    else: xy_nor = unit(side.cells[1].center-side.center)
                    if side.id == 0: J = array([xy_nor, xy_tan]).T
                    else: J = array([-xy_tan, xy_nor]).T #!!!!!
                    side.J = Jacobi_inverse(J)

    def interpolation_inner_P(self):
        '''
        Xác định giá P trên các mặt bên trong bằng hàm nội suy
        Giá trị P trên các mặt biên đã được xác định bằng các hàm boco
        '''
        for side in self.inner_sides:
            cl = side.cells[0]
            cr = side.cells[1]
            dl = cl.size[side.id]
            dr = cr.size[side.id]
            side.P = interpolation(cl.P, dl, cr.P, dr)


    def gradient(self):
        '''Xác định gradient trên tất cả các mặt'''
        for side in self.inner_sides:
            cl = side.cells[0]
            cr = side.cells[1]
            id0 = side.id       # hướng pháp tuyến
            id1 = (id0+1)%2     # hướng tiếp tuyến
            dl = 0.5*cl.size[id0]
            dr = 0.5*cr.size[id0]
            d  = dl + dr
            G = zeros((2,4))
            G[id1] = interpolation(cl.G[id1], dl, cr.G[id1], dr)
            G[id0] = (cr.P-cl.P)/d + (cr.G[id0]-cl.G[id0])/d*0.5*(dl-dr)
            side.G = G

        for i, bound in enumerate(self.bounds):
            id0 = bound_side_id(i)  # hướng pháp tuyến
            id1 = (id0+1)%2         # hướng tiếp tuyến
            ic = (i + 1) % 2    # index của inner cell
            if ic == 0: nc = i-1
            else: nc = i+1      # index của next cell
            si = sign_ic(ic)
            for side in bound:
                if side.joint == False:
                    c1 = side.cells[ic]
                    c2 = c1.cells[nc]
                    d1 = 0.5*c1.size[id0]
                    d2 = 0.5*(c1.size[id0]+c2.size[id0])
                    G = zeros((2, 4))
                    # G[id1] = c1.G[id1]
                    G[id1] = extrapolation(c1.G[id1], d1, c2.G[id1], d2)
                    G1 = (c1.P - side.P)/d1
                    # G2 = (c2.P - c1.P)/d2
                    # G[id0] = si*extrapolation(G1, d1, G2, d2)
                    G[id0] = si*G1
                    side.G = G

            # với biên wall set gradient vận tốc theo phương tiếp tuyến bằng 0.0
            for boco in self.boco_list[i]:
                if (boco[0] is no_slip) or (boco[0] is moving_wall):
                    for side in bound[boco[1]:boco[2]]:
                        side.G[id1][1:3] =  0.0

                # elif (boco[0] is symmetry):
                #     for side in bound[boco[1]:boco[2]]:
                #         Gsym = Psym(side.cells[ic].G[id1], side.normal)
                #         side.G[id1] = 0.5 * (side.cells[ic].G[id1] + Gsym)

        return

    def flux_diffusion(self):
        '''Tính dòng khuếch tán qua mặt ô lưới'''
        for side in self.inner_sides:
            Gxy = side.J.T.dot(side.G) # Tính gradient theo tọa độ xy
            F = P2F_diff(side.P, Gxy, side)
            side.cells[0].res -= F # ô bên trái -
            side.cells[1].res += F # ô bên phải +

        for i, bound in enumerate(self.bounds):
            ic = (i + 1) % 2  # index inner cell
            sc = sign_ic(ic)
            for side in bound:
                if side.joint == False:
                    Gxy = side.J.T.dot(side.G) # Tính gradient theo tọa độ xy
                    F = P2F_diff(side.P, Gxy, side)
                    side.cells[ic].res += sc*F
        return

'''
    ------------------------------------
    Phần III: Lớp dữ liệu "Blocks"
    ------------------------------------
'''

class euBlock:
    '''
    Lớp dữ liệu Block chứa các dữ liệu của một vùng tính toán (block, zone).

    Parameters
    ----------
    name  : tên block
    nodes : mảng tọa độ các điểm lưới

    Attributes
    ----------
    BField : file chứa trường khí động 'name.field'
    BNodes : các điểm lưới
    BCells : các ô lưới "class Cells"
    BSides : các mặt "class Sides"
    BSize  : kích thước lưới
    '''
    def __init__(self,  name, nodes):
        '''Khởi tạo Block có tên "name", có tọa độ điểm lưới "nodes".'''
        self.BField = path_dir+name+'.field'
        self.BNodes = nodes
        self.BCells = euCells(nodes)
        self.BSides = euSides(nodes, self.BCells)
        self.BSize = self.BCells.size

    def iteration(self, flux_func, dt):
        '''
        Mỗi bước lặp bao gồm:
            set_boco() : xác định các Ghost Ceels
            flux_bound_sides() : tính dòng qua các sides trên biên
            flux_inner_sides() : tính dòng qua các sides trong vùng tính
            new_U : xác định U ở bước thời gian tiếp theo
            new_P : xác định P ở bước thời gian tiếp theo

        :param flux_func: hàm tính dòng qua side
        :param dt: bước thời gian
        '''
        self.BSides.flux_bound_sides(flux_func)
        self.BSides.flux_inner_sides(flux_func)
        self.BCells.new_U(dt)
        self.BCells.new_P()

    def write_field(self):
        '''Ghi trường khí động dạng vào file binary BField.'''
        BData = array([cell.P for cell in self.BCells])
        f = open(self.BField, 'wb')
        BData.tofile(f)
        f.close()

    def read_field(self):
        '''Đọc trường khí động từ file binary BField.'''
        f = open(self.BField, 'rb')
        BData = fromfile(f).reshape((self.BCells.len, 4))
        f.close()
        for i, cell in enumerate(self.BCells):
            cell.P = BData[i]
            cell.U = P2U(BData[i])

    def init_field(self, P_t0):
        '''
        Thiết lập trường khí động tại thời điểm ban đầu.
        :param P_t0 : numpy.array(rho, u, v, p)
        '''
        U_t0 = P2U(P_t0)
        for cell in self.BCells:
            cell.P = P_t0.copy()
            cell.U = U_t0.copy()


class nsBlock(euBlock):
    def __init__(self, name, nodes):
        '''Khởi tạo Block có tên "name", có tọa độ điểm lưới "nodes".'''
        self.BField = path_dir + name + '.field'
        self.BNodes = nodes
        self.BCells = nsCells(nodes)
        self.BSides = nsSides(nodes, self.BCells)
        self.BSize = self.BCells.size

    def iteration(self, flux_func, dt):
        '''Thực hiện bước lặp'''
        self.BSides.flux_bound_sides(flux_func)
        self.BSides.flux_inner_sides(flux_func)
        self.BSides.interpolation_inner_P()
        self.BCells.gradient_central_diff()
        self.BSides.gradient()
        self.BSides.flux_diffusion()
        self.BCells.new_U(dt)
        self.BCells.new_P()

class Blocks():
    '''
    Lớp dữ liệu Blocks chứa tất cả các blocks trong vùng tính toán và có chức năng thực hiên
    tất cả các bước tính toán khí động.

    Parameters
    ----------
    meshfile : file lưới ở định dạng Tecplot

    Attributes
    ----------
    len:
            số lượng các blocks
    blocks:
            dãy các blocks
    time_step_global:
            bước thời gian trong toàn bộ vùng tính toán
    state_file:
            file trạng thái tính toán, chứ hai thông số của bước lặp cuối cùng - iter, time
    '''
    def __init__(self, btype='eu', meshfile=mesh_file):
        '''Khởi tạo Blocks từ file lưới "meshfile".'''
        start_time = timer()
        self.state_file = path_dir+'solver.state'
        self.time_step_global = 1e6
        # số lượng block; tên block, tọa độ điểm lưới trong mỗi block
        zone_n, zone_names, zone_nodes = import_mesh(meshfile)
        self.len = zone_n
        self.blocks = []
        if btype == 'eu':
            for n in range(zone_n):
                block = euBlock(zone_names[n], zone_nodes[n])
                self.blocks.append(block)

        elif btype == 'ns':
            for n in range(zone_n):
                block = nsBlock(zone_names[n], zone_nodes[n])
                self.blocks.append(block)

        else:
            print("The type of the solver must be eu or ns!")
            exit(0)

        print('The time taken by init_block is %f seconds!' % (timer() - start_time))

    def __getitem__(self, item):
        '''Lấy phần tử của dãy Blocks.'''
        return self.blocks[item]

    def read_field(self):
        '''Đọc trường khí động.'''
        start_time = timer()
        for block in self.blocks: block.read_field()
        print('The time taken by read_field is %f seconds!\n' % (timer() - start_time))


    def write_field(self):
        '''Ghi trường khí động.'''
        for block in self.blocks: block.write_field()

    def init_field_test1D(self, P_left, P_right):
        '''Thiết lập điều kiện ban đầu cho test1D, lưới 1 block.'''
        start_time = timer()
        with open(self.state_file, 'w') as f: f.write('iter time:\n%d %f' % (0, 0.0))

        U_left  = P2U(P_left)
        U_right = P2U(P_right)

        cells = self.blocks[0].BCells
        Ni = cells.len
        Nih = int(Ni/2)
        for cell in cells[: Nih]:
            cell.P = P_left.copy()
            cell.U = U_left.copy()
        for cell in cells[Nih:]:
            cell.P = P_right.copy()
            cell.U = U_right.copy()

        self.write_field()
        print('The time taken by init_field is %f seconds!' % (timer() - start_time))

    def init_field(self, P_t0=P_freestream):
        '''Thiết lập điều kiện ban đầu, ghi trường khí động.'''
        start_time = timer()
        with open(self.state_file, 'w') as f: f.write('iter time:\n%d %f' % (0, 0.0))
        for block in self.blocks: block.init_field(P_t0)
        self.write_field()
        print('The time taken by init_field is %f seconds!' % (timer() - start_time))

    def iteration(self, flux_func):
        '''Thực hiện bước lặp thời gian.'''
        for block in self.blocks: block.iteration(flux_func, self.time_step_global)

    def joint(self, joints = joint_list):
        '''
        Kết nối các biên có điều kiện biên joint.
        :param  joint_list : [joint_0, joint_1, ...]
                joint_0 = [blk1_id, bound1_id, start_side1_id, end_side1_id,
                           blk2_id, bound2_id, start_side2_id, end_side2_id]
        '''
        if joints is not None:
            for joint in joints:
                left_BSides = self.blocks[joint[0]].BSides
                left_bound = left_BSides.bounds[joint[1]][joint[2]:joint[3]]

                right_BSides = self.blocks[joint[4]].BSides
                right_bound = right_BSides.bounds[joint[5]][joint[6]:joint[7]]

                left_BSides.set_joint(left_bound, right_bound, ib0=joint[1], ib1=joint[5])

    def set_time_step(self, CFL):
        '''Xác định bước thời gian trong toàn bộ vùng tính.'''
        for block in self.blocks:
            dt = block.BCells.time_step_global(CFL)
            self.time_step_global = min(self.time_step_global, dt)
        return self.time_step_global

    def run(self, solver=eu_solver, joints=joint_list, bocos=boco_list):
        '''
        Toàn bộ các bước tính toán trường khí động:
                        joint -> set_boco_list -> read_field -> solve
        :param solver : hàm solver thực hiện các bước lặp  Block.iteration.
        '''
        print('**************************************************')
        start_time = timer()
        self.joint(joints)
        for i, block in enumerate(self.blocks): block.BSides.set_boco_list(bocos[i])
        self.read_field()
        solver(self)
        print('\nThe time taken by solver is %f seconds!' % (timer() - start_time))
        print('**************************************************')

    def export_block_data(self, filename):
        '''Xuất trường khí động vào file định dạng Tecplot block data.'''
        filename = path_dir + filename
        print('Write block data to: %s' % filename)
        f = open(filename, 'w')
        f.write('TITLE = "vncfd field"\n')
        f.write('VARIABLES = "X", "Y", "rho", "u", "v", "p", "Mach", "T"\n')

        n = 0
        for block in self.blocks:
            n += 1
            nodes = block.BNodes
            cells = block.BCells
            f.write('ZONE T="%d", I=%d, J=%d, DATAPACKING=BLOCK, VARLOCATION=([3,4,5,6,7,8]=CELLCENTERED)\n' % (
            n, nodes.shape[1], nodes.shape[0]))

            X_p, Y_p = nodes[:, :, 0].ravel(), nodes[:, :, 1].ravel()
            for x in X_p: f.write('%.8f ' % x)
            f.write('\n')
            for y in Y_p: f.write('%.8f ' % y)
            f.write('\n')

            for i in range(4):
                for cell in cells: f.write('%.8f ' % cell.P[i])
                f.write('\n')
            for cell in cells:
                M = Mach(cell.P)
                f.write('%.8f ' % M)
            for cell in cells:
                T = Temperature(cell.P)
                f.write('%.8f ' % T)
            f.write('\n')
        f.close()

    def plot_field(self, field='rho', pfunc='pcolor'): #or contourf
        '''Plot trường khí động. Tốt nhất hãy sử dụng Paraview!'''
        id = {'rho':0, 'u':1, 'v':2, 'p':3} #'M' - Mach number
        for block in self.blocks:
            nodes = block.BNodes
            cells = block.BCells
            Nj, Ni = cells.size[0], cells.size[1]
            if field == 'M': value_c = array([Mach(cell.P) for cell in cells]).reshape((Nj, Ni))
            else: value_c = array([cell.P[id[field]] for cell in cells]).reshape((Nj, Ni))

            if pfunc == 'pcolor':
                X_p, Y_p = nodes[:, :, 0], nodes[:, :, 1]
                pcm = plt.pcolor(X_p, Y_p, value_c)
            else:
                centers = array([cell.center for cell in cells]).reshape((Nj, Ni, 2))
                X_c, Y_c = centers[:, :, 0], centers[:, :, 1]
                pcm = plt.contourf(X_c, Y_c, value_c)

        plt.title(field)
        plt.show()