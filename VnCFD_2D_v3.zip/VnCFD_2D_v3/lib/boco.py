# coding: utf-8
# Copyright (C) 2019  Nguyen Ngoc Sang, <https://github.com/SangVn>

from numpy import array
from constants import gamma, gamma_m1
from functions import Mach, VSound, P2F, sign_ic, opposite_ic
from fluxes import decay_roe_python

P_freestream = None # thông số dòng tự do
p_exit = None # áp suất tại mặt outlet
U_moving_wall = None # vận tốc chuyển động của biên

def set_boco_const(Pfree=None, pexit=None, U_movingWall=None):
    global  P_freestream, p_exit, U_moving_wall
    P_freestream = Pfree
    p_exit = pexit
    U_moving_wall = U_movingWall

# Điều kiện dòng chảy vào: P_out = P_freestream
def supersonic_inflow(boundary, ic, flux_func):
    oc = opposite_ic(ic)
    sc = sign_ic(ic)
    for side in boundary:
        # F = P2F(P_freestream, side) # có thể tính trực tiếp F
        side.P = P_freestream
        side.cells[oc].P = side.P
        # F = P2F(side.P, side)
        F = flux_func(side, side.cells[0].P, side.cells[1].P)
        side.cells[ic].res += sc * F

# Điều kiện dòng chảy ra: P_out = P_in
def supersonic_outflow(boundary, ic, flux_func):
    oc = opposite_ic(ic)
    sc = sign_ic(ic)
    for side in boundary:
        side.P = side.cells[ic].P
        side.cells[oc].P = side.P
        F = P2F(side.cells[ic].P, side)
        # F = flux_func(side, side.cells[0].P, side.cells[1].P)
        side.cells[ic].res += sc * F

# Điều kiện biên no_slip: P_side: u=v=0, dp/dn=0, drho/dn=0
def no_slip(boundary, ic, flux_func):
    oc = opposite_ic(ic)
    sc = sign_ic(ic)
    for side in boundary:
        P_in = side.cells[ic].P
        side.P = array([P_in[0], 0.0, 0.0, P_in[3]]) # P trên biên
        side.cells[oc].P = side.P # P trên biên
        # P_out = array([P_in[0], -P_in[1], -P_in[2], P_in[3]]) # P ở ghost cell
        F = P2F(side.P, side)
        side.cells[ic].res += sc*F


# symmetry and slip boco are the same: V_out = V_in - 2(V_in.n)n
def symmetry(boundary, ic, flux_func):
    oc = opposite_ic(ic)
    sc = sign_ic(ic)
    for side in boundary:
        P_in = side.cells[ic].P
        V_in = P_in[1:3]
        Vn = side.normal.dot(V_in)
        # V_out = V_in - 2*Vn*side.normal # V ở ghost cell
        V_b = V_in -  Vn * side.normal  # V trên biên
        side.P = array([P_in[0], V_b[0], V_b[1], P_in[3]])
        side.cells[oc].P = side.P
        F = P2F(side.P, side)
        # F = flux_func(side, side.cells[0].P, side.cells[1].P)
        side.cells[ic].res += sc * F

# Điều kiện biên farfield: P_out = P_freestream
def farfield(boundary, ic, flux_func):
    oc = opposite_ic(ic)
    sc = sign_ic(ic)
    for side in boundary:
        side.P = 0.5*(P_freestream + side.cells[ic].P)
        side.cells[oc].P = side.P
        # F = P2F(P_freestream, side)
        F = flux_func(side, side.cells[0].P, side.cells[1].P)
        side.cells[ic].res += sc * F

# Điều kiện biên outflow xác định theo các đường đặc trưng
def outflow(boundary, ic, flux_func):
    oc = opposite_ic(ic)
    sc = sign_ic(ic)
    for side in boundary:
        P_in = side.cells[ic].P
        rho_b = P_in[0]*(p_exit/P_in[3])**(1.0/gamma)
        a_b = (gamma*p_exit/rho_b)**0.5
        Vn_in = side.normal.dot(P_in[1:3])
        a_in = VSound(P_in)
        R_p = Vn_in + 2*a_in/(gamma_m1)
        Vn_b = R_p - 2*a_b/(gamma_m1)
        V_b = P_in[1:3] + (Vn_b - Vn_in)*side.normal
        P_b = [rho_b, V_b[0], V_b[1], p_exit]
        side.P = P_b
        side.cells[oc].P = side.P
        F = P2F(P_b, side)
        # F = flux_func(side, side.cells[0].P, side.cells[1].P) #(side, P_in, P_b)
        side.cells[ic].res += sc * F

# Điều kiện biên inlow xác định theo các đường đặc trưng
def inflow(boundary, ic, flux_func):
    oc = opposite_ic(ic)
    sc = sign_ic(ic)
    P_e = P_freestream
    for side in boundary:
        Vn_e = side.normal.dot(P_e[1:3])
        a_e = VSound(P_e)
        if (Vn_e >= a_e or Vn_e <= -a_e):
            P_b = P_e
        else:
            P_in = side.cells[ic].P
            Vn_in = side.normal.dot(P_in[1:3])
            a_in = VSound(P_in)
            R_p = Vn_e + 2 * a_e / (gamma_m1)
            R_m = Vn_in - 2 * a_in / (gamma_m1)
            Vn_b = 0.5*(R_p+R_m)
            a_b = 0.25*(gamma_m1)*(R_p - R_m)
            V_b = P_e[1:3] + (Vn_b - Vn_e)*side.normal
            R = P_e[3]/(P_e[0]**gamma)
            rho_b = (a_b*a_b/(gamma*R))**(1.0/gamma_m1)
            p_b = R*rho_b**gamma
            P_b = [rho_b, V_b[0], V_b[1], p_b]

        side.P = P_b
        side.cells[oc].P = side.P
        F = P2F(P_b, side)
        # F = flux_func(side, side.cells[0].P, side.cells[1].P) #(side, P_b, P_in)
        side.cells[ic].res += sc*F

def moving_wall(boundary, ic, flux_func):
    oc = opposite_ic(ic)
    sc = sign_ic(ic)
    for side in boundary:
        P_in = side.cells[ic].P
        side.P = array([P_in[0], U_moving_wall[0], U_moving_wall[1], P_in[3]]) # P trên biên
        side.cells[oc].P = side.P # P trên biên
        F = P2F(side.P, side)
        # F = flux_func(side, side.cells[0].P, side.cells[1].P)
        side.cells[ic].res += sc*F

# Điều kiện biên joint
def joint(boundary, ic, flux_func):
    pass

# Điều kiện biên null
def null(boundary, ic, flux_func):
    pass
