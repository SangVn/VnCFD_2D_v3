# coding: utf-8
# Copyright (C) 2019  Nguyen Ngoc Sang, <https://github.com/SangVn>

# ví dụ 1:
# from examples.nozzle.setting import *
# path_dir = 'examples/nozzle/'

# ví dụ 2:
# from examples.wedge.setting import *
# path_dir = 'examples/wedge/'

# ví dụ 3:
# from examples.naca0012.setting import *
# path_dir = 'examples/naca0012/'

# ví dụ 4:
# from examples.test1D.setting import *
# path_dir = 'examples/test1D/'

#ví dụ 5:
# from examples.lid_driven_cavity.setting import *
# path_dir = 'examples/lid_driven_cavity/'

# ví dụ 6:
# from examples.backstep.setting import *
# path_dir = 'examples/backstep/'

# ví dụ 7:
# from examples.laminar_flat_plate.setting import *
# path_dir = 'examples/laminar_flat_plate/'

# ví dụ 8:
from examples.cylinder.setting import *
path_dir = 'examples/cylinder/'
