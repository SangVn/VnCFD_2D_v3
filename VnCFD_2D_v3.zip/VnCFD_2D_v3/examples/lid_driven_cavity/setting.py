# coding: utf-8
# Copyright (C) 2019  Nguyen Ngoc Sang, <https://github.com/SangVn>

# Bài toán lid-driven Cavity
# https://www.grc.nasa.gov/WWW/wind/valid/cavity/cavity.html

from lib.functions import Pm2P, reynolds_number
from lib.fluxes import *
from lib.boco import *

# Trước hết cần chỉ rõ đường dẫn của file lưới
mesh_file = 'examples/lid_driven_cavity/cavity_coarse.mesh'

# 1 psia = 6894.75728 pascal
# 1 Rankine × 5/9 = 0,5556 Kelvin
# 1 inch = 0.0254 m

# Case A
p0 = 0.0425*6894.75728
T0 = 460*5/9
P_freestream = Pm2P(M=0.05, T=T0, p=p0, alf=0.0)
print(reynolds_number(P_freestream, 0.0254))

P_t0 = array([P_freestream[0], 0.0, 0.0, P_freestream[3]])
U_wall = (P_freestream[1], P_freestream[2])

# Đăt điều kiện biên: boco_i = [(name, start_side_index, end_side_index), (...)]
def set_boco():
    # hàm set_boco_const thiết lập vận tốc chuyên động của nắp hộp 
    set_boco_const(U_movingWall=U_wall)

    blk1_bc_0 = [(no_slip, None, None)]  # Điều kiện biên bound_0 là no_slip
    blk1_bc_1 = [(no_slip, None, None)]  # Điều kiện biên bound_1 là no_slip
    blk1_bc_2 = [(no_slip, None, None)]  # Điều kiện biên bound_2 là no_slip
    blk1_bc_3 = [(moving_wall, None, None)]  # Điều kiện biên bound_3 là moving_wall
    # (..., None, None) nghĩa là bắt đầu từ side đầu tiên tới side cuối cùng trên biên
    blk1_bc_list = [blk1_bc_0, blk1_bc_1, blk1_bc_2, blk1_bc_3]  # list các điều kiện biên của block 1

    boco_list = [blk1_bc_list]
    joint_list = None
    return boco_list, joint_list


boco_list, joint_list = set_boco()

# các thông số khác
CFL = 0.95
time_target = None
iter_target = 10000

# thời điểm ghi kết quả giữa chừng
write_field_frequency_time = None
write_field_frequency_iter = 5000

# thời điểm hiển thị các thông số cơ bản của một bước
print_frequency_iter = 100

# lựa chọn hàm tính flux, hàm flux_roe_fortran đã được include trong lib.boco
flux_func = flux_roe_fortran
