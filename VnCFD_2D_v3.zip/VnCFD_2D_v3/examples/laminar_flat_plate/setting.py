# coding: utf-8
# Copyright (C) 2019  Nguyen Ngoc Sang, <https://github.com/SangVn>

# Bài toán lid-driven Cavity
# https://www.grc.nasa.gov/WWW/wind/valid/fplam/fplam01/fplam01.html

from lib.functions import Pm2P, reynolds_number
from lib.fluxes import *
from lib.boco import *

# Trước hết cần chỉ rõ đường dẫn của file lưới
mesh_file = 'examples/laminar_flat_plate/plate.mesh'

# 1 psia = 6894.75728 pascal
# 1 Rankine × 5/9 = 0,5556 Kelvin
# 1 inch = 0.0254 m
# 1 ft = 0,3048 m

# Case A
p0 = 6.0*6894.75728
T0 = 700.0*5.0/9.0
P_freestream = Pm2P(M=0.1, T=T0, p=p0, alf=0.0)

print(P_freestream)
print(reynolds_number(P_freestream, 0.3048))

P_t0 = array([P_freestream[0], 0.0, 0.0, P_freestream[3]])
pressure_exit = P_freestream[3]

# Đăt điều kiện biên: boco_i = [(name, start_side_index, end_side_index), (...)]
def set_boco():
    # hàm set_boco_const thiết lập vận tốc chuyên động của nắp hộp
    set_boco_const(Pfree=P_freestream, pexit=pressure_exit)

    blk1_bc_0 = [(inflow, None, None)]  # Điều kiện biên bound_0 là no_slip
    blk1_bc_1 = [(outflow, None, None)]  # Điều kiện biên bound_1 là no_slip
    blk1_bc_2 = [(symmetry, None, 10), (no_slip, 10, None)]  # Điều kiện biên bound_2 là no_slip
    blk1_bc_3 = [(farfield, None, None)]  # Điều kiện biên bound_3 là moving_wall
    # (..., None, None) nghĩa là bắt đầu từ side đầu tiên tới side cuối cùng trên biên
    blk1_bc_list = [blk1_bc_0, blk1_bc_1, blk1_bc_2, blk1_bc_3]  # list các điều kiện biên của block 1

    boco_list = [blk1_bc_list]
    joint_list = None
    return boco_list, joint_list


boco_list, joint_list = set_boco()

# các thông số khác
CFL = 0.95
time_target = None
iter_target = 20000

# thời điểm ghi kết quả giữa chừng
write_field_frequency_time = None
write_field_frequency_iter = 5000

# thời điểm hiển thị các thông số cơ bản của một bước
print_frequency_iter = 100

# lựa chọn hàm tính flux, hàm flux_roe_fortran đã được include trong lib.boco
flux_func = flux_roe_fortran
