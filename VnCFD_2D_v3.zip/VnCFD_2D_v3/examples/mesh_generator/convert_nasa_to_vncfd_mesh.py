import numpy as np
from mesh_generator import export_mesh

def convert(infile, outfile):
	f = open(infile, 'r')
	size = f.readline()
	data = f.readline()
	f.close()
	size = size.split()
	data = data.split()

	size = np.array([int(s) for s in size])
	data = np.array([float(d) for d in data])

	N = size[0]*size[1]
	x = data[0:N].reshape(size[1], size[0])
	y = data[N:2*N].reshape(size[1], size[0])
	nodes2 = np.zeros((size[1], size[0], 2))

	#r = 0.0254 #inch -> m
	r = 0.3048 #ft -> m

	nodes2[:, :, 0] = x*r
	nodes2[:, :, 1] = y*r

	export_mesh([nodes2], outfile)

if __name__ == "__main___":
    
    convert('fplam.d', '../laminar_flat_plate/plate_fine.mesh')
