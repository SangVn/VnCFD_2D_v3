to run fortran module:
gfortran 'name.f'
./a.out
